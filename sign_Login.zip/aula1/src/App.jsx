import { useState } from 'react'
import './App.css'

function App() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (isRegistering) {
      // Registrar usuário
      localStorage.setItem(username, password);
      alert(`User ${username} registered successfully!`);
      setIsRegistering(false);
    } else {
      // Validar usuário
      const storedPassword = localStorage.getItem(username);

      if (storedPassword === password) {
        alert('Login successful!');
      } else {
        alert('Invalid username or password.');
      }
    }
  };

  return (
    <div className="App">
      <form onSubmit={handleSubmit}>
      <h1>{isRegistering ? 'Sign-in' : 'Login'}</h1>
      <div>
        <label htmlFor="username">Username:</label>
        <input type="text" id="username" value={username} onChange={(e) => setUsername(e.target.value)} />
      </div>
      <div>
        <label htmlFor="password">Password:</label>
        <input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} />
      </div>
      {error && <div className="error">{error}</div>}
      <button type="submit">{isRegistering ? 'Sign-in' : 'Login'}</button>
      <button type="button" onClick={() => setIsRegistering(!isRegistering)}>
        {isRegistering ? 'Login' : 'Sign-in'}
      </button>
    </form>
    </div>
  )
}

export default App
